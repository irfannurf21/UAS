------------------------------ TUGAS BESAR  ------------------------------------
CREATE OR REPLACE PACKAGE inur_pkg AS
    PROCEDURE insert_foto (ID_PAKET VARCHAR2, NAMA_PAKET VARCHAR2, HARGA NUMBER);
    PROCEDURE insert_pelanggan (ID_PELANGGAN VARCHAR2, NAMA_PELANGGAN VARCHAR2, NOTEL NUMBER, ALAMAT VARCHAR2);
    PROCEDURE insert_pemesanan (ID_PEMESANAN VARCHAR2, ID_PELANGGAN VARCHAR2, TANGGAL_PEMESANAN DATE);
    PROCEDURE insert_status (ID_PEMESANAN VARCHAR2, ID_PAKET VARCHAR2, STATUS VARCHAR2);
    PROCEDURE update_foto (nID_PAKET VARCHAR2, new_NAMA_PAKET VARCHAR2, new_HARGA NUMBER);
    PROCEDURE update_pelanggan (nID_PELANGGAN VARCHAR2, new_NAMA_PELANGGAN VARCHAR2, new_NOTEL NUMBER, new_ALAMAT VARCHAR2);
    PROCEDURE update_pemesanan (nID_PEMESANAN VARCHAR2, new_TANGGAL_PEMESANAN DATE);
    PROCEDURE update_status (nID_PEMESANAN VARCHAR2, new_STATUS VARCHAR2);
    PROCEDURE delete_foto (nID_PAKET VARCHAR2);
    PROCEDURE delete_pelanggan (nID_PELANGGAN VARCHAR2);
    PROCEDURE delete_pemesanan (nID_PEMESANAN VARCHAR2);
    PROCEDURE delete_status (nID_PEMESANAN VARCHAR2);
    PROCEDURE view_foto (ID_PAKET IN VARCHAR2 DEFAULT NULL);
    PROCEDURE view_pelanggan (ID_PELANGGAN IN VARCHAR2 DEFAULT NULL);
    PROCEDURE view_pemesanan (ID_PEMESANAN IN VARCHAR2 DEFAULT NULL);
    PROCEDURE view_status (ID_PEMESANAN IN VARCHAR2 DEFAULT NULL);
    FUNCTION hitung_jumlah_harga (HARGA_INPUT NUMBER) RETURN NUMBER;
    FUNCTION hitung_jumlah_alamat_pelanggan (ALAMAT_INPUT IN VARCHAR2) RETURN NUMBER;
    FUNCTION hitung_jumlah_pelanggan_pesan (PELANGGAN_INPUT IN VARCHAR2) RETURN NUMBER;
    FUNCTION hitung_jumlah_status (STATUS_INPUT IN VARCHAR2) RETURN NUMBER;
END inur_pkg;
/   

CREATE OR REPLACE PACKAGE BODY inur_pkg AS
---------------------------- PROCEDURE INPUT -----------------------------------
    PROCEDURE insert_foto (ID_PAKET VARCHAR2, NAMA_PAKET VARCHAR2, HARGA NUMBER) IS
    BEGIN
        INSERT INTO PAKETFOTO (ID_PAKET, NAMA_PAKET, HARGA) VALUES (ID_PAKET, NAMA_PAKET, HARGA);
        COMMIT;
    END insert_foto;
    
    PROCEDURE insert_pelanggan (ID_PELANGGAN VARCHAR2, NAMA_PELANGGAN VARCHAR2, NOTEL NUMBER, ALAMAT VARCHAR2) IS
    BEGIN
        INSERT INTO PELANGGAN (ID_PELANGGAN, NAMA_PELANGGAN, NOTEL, ALAMAT) 
        VALUES (ID_PELANGGAN, NAMA_PELANGGAN, NOTEL, ALAMAT);
        COMMIT;
    END insert_pelanggan;
    
    PROCEDURE insert_pemesanan (ID_PEMESANAN VARCHAR2, ID_PELANGGAN VARCHAR2, TANGGAL_PEMESANAN DATE) IS
    BEGIN
        INSERT INTO PEMESANAN (ID_PEMESANAN, ID_PELANGGAN, TANGGAL_PEMESANAN) 
        VALUES (ID_PEMESANAN, ID_PELANGGAN, TANGGAL_PEMESANAN);
        COMMIT;
    END insert_pemesanan;
    
    PROCEDURE insert_status (ID_PEMESANAN VARCHAR2, ID_PAKET VARCHAR2, STATUS VARCHAR2) IS
    BEGIN
        INSERT INTO STATUS_PEMESANAN (ID_PEMESANAN, ID_PAKET, STATUS) 
        VALUES (ID_PEMESANAN, ID_PAKET, STATUS);
        COMMIT;
    END insert_status;
    
--------------------------- PROCEDURE UPDATE -----------------------------------
    PROCEDURE update_foto (nID_PAKET VARCHAR2, new_NAMA_PAKET VARCHAR2, new_HARGA NUMBER) IS
    BEGIN
        UPDATE PAKETFOTO SET NAMA_PAKET = new_NAMA_PAKET, HARGA = new_HARGA WHERE ID_PAKET = nID_PAKET;
    END update_foto;
    
    PROCEDURE update_pelanggan (nID_PELANGGAN VARCHAR2, new_NAMA_PELANGGAN VARCHAR2, new_NOTEL NUMBER, new_ALAMAT VARCHAR2) IS
    BEGIN
        UPDATE PELANGGAN SET NAMA_PELANGGAN = new_NAMA_PELANGGAN, ALAMAT = new_ALAMAT WHERE ID_PELANGGAN = nID_PELANGGAN;
    END update_pelanggan;
    
    PROCEDURE update_pemesanan (nID_PEMESANAN VARCHAR2, new_TANGGAL_PEMESANAN DATE) IS
    BEGIN
        UPDATE PEMESANAN SET TANGGAL_PEMESANAN = new_TANGGAL_PEMESANAN WHERE ID_PEMESANAN = nID_PEMESANAN;
    END update_pemesanan;
    
    PROCEDURE update_status (nID_PEMESANAN VARCHAR2, new_STATUS VARCHAR2) IS
    BEGIN
        UPDATE STATUS_PEMESANAN SET STATUS = new_STATUS WHERE ID_PEMESANAN = nID_PEMESANAN;
    END update_status;

    
--------------------------- PROCEDURE DELETE -----------------------------------
    PROCEDURE delete_foto (nID_PAKET VARCHAR2) IS
    BEGIN 
        DELETE FROM PAKETFOTO WHERE ID_PAKET = nID_PAKET;
    END delete_foto;
    
    PROCEDURE delete_pelanggan (nID_PELANGGAN VARCHAR2) IS
    BEGIN 
        DELETE FROM PELANGGAN WHERE ID_PELANGGAN = nID_PELANGGAN;
    END delete_pelanggan;
    
    PROCEDURE delete_pemesanan (nID_PEMESANAN VARCHAR2) IS
    BEGIN 
        DELETE FROM PEMESANAN WHERE ID_PEMESANAN = nID_PEMESANAN;
    END delete_pemesanan;
    
    PROCEDURE delete_status (nID_PEMESANAN VARCHAR2) IS
    BEGIN 
        DELETE FROM STATUS_PEMESANAN WHERE ID_PEMESANAN = nID_PEMESANAN;
    END delete_status;
    
    
---------------------------- PROCEDURE VIEW ------------------------------------
    PROCEDURE view_foto (ID_PAKET IN VARCHAR2 DEFAULT NULL) IS
        CURSOR cfoto IS SELECT * FROM PAKETFOTO where ID_PAKET like '%' ||ID_PAKET|| '%';
    BEGIN  
        FOR i IN cfoto LOOP
            DBMS_OUTPUT.PUT_LINE ('ID_PAKET : ' || i.ID_PAKET || ' | Nama  Paket : ' || i.NAMA_PAKET ||
            ' | Harga : Rp ' || i.HARGA);
        END LOOP;
    END view_foto;
    
    PROCEDURE view_pelanggan (ID_PELANGGAN IN VARCHAR2 DEFAULT NULL) IS
        CURSOR cpelanggan IS SELECT * FROM PELANGGAN where ID_PELANGGAN like '%' ||ID_PELANGGAN|| '%';
    BEGIN  
        FOR i IN cpelanggan LOOP
            DBMS_OUTPUT.PUT_LINE ('ID Pelanggan : ' || i.ID_PELANGGAN || ' | Nama  Pelanggan : ' || i.NAMA_PELANGGAN ||
            ' | Nomor Telepon : ' || i.NOTEL || ' | Alamat : ' || i.ALAMAT );
        END LOOP;
    END view_pelanggan;
    
    PROCEDURE view_pemesanan (ID_PEMESANAN IN VARCHAR2 DEFAULT NULL) IS
        CURSOR cpemesanan IS SELECT * FROM PEMESANAN where ID_PEMESANAN like '%' ||ID_PEMESANAN|| '%';
    BEGIN  
        FOR i IN cpemesanan LOOP
            DBMS_OUTPUT.PUT_LINE ('ID Pemesanan : ' || i.ID_PEMESANAN || ' | ID pelanggan : ' || i.ID_PELANGGAN ||
            ' | Tanggal pemesanan : ' || i.TANGGAL_PEMESANAN);
        END LOOP;
    END view_pemesanan;
    
    PROCEDURE view_status (ID_PEMESANAN IN VARCHAR2 DEFAULT NULL) IS
        CURSOR cstatus IS SELECT * FROM STATUS_PEMESANAN where ID_PEMESANAN like '%' ||ID_PEMESANAN|| '%';
    BEGIN  
        FOR i IN cstatus LOOP
            DBMS_OUTPUT.PUT_LINE ('ID Pemesanan : ' || i.ID_PEMESANAN || ' | ID Paket : ' || i.ID_PAKET ||
            ' | Status : ' || i.STATUS);
        END LOOP;
    END view_status;
    
------------------------- FUNCTION & EXCEPTION ---------------------------------
    FUNCTION hitung_jumlah_harga (HARGA_INPUT IN NUMBER) RETURN NUMBER IS
        jumlah NUMBER := 0;
    BEGIN
      SELECT COUNT(*) INTO jumlah
      FROM PAKETFOTO
      WHERE HARGA = HARGA_INPUT;
      RETURN jumlah;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('tidak ada data ditemukan');
    RETURN 0;
    END hitung_jumlah_harga;
    
    FUNCTION hitung_jumlah_alamat_pelanggan (ALAMAT_INPUT IN VARCHAR2) RETURN NUMBER IS
        jumlah NUMBER := 0;
    BEGIN
      SELECT COUNT(*) INTO jumlah
      FROM PELANGGAN
      WHERE ALAMAT = ALAMAT_INPUT;
      RETURN jumlah;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('tidak ada data ditemukan');
    RETURN 0;
    END hitung_jumlah_alamat_pelanggan;
    
    FUNCTION hitung_jumlah_pelanggan_pesan (PELANGGAN_INPUT IN VARCHAR2) RETURN NUMBER IS
        jumlah NUMBER := 0;
    BEGIN
      SELECT COUNT(*) INTO jumlah
      FROM PEMESANAN
      WHERE ID_PELANGGAN = PELANGGAN_INPUT;
      RETURN jumlah;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('tidak ada data ditemukan');
    RETURN 0;
    END hitung_jumlah_pelanggan_pesan;
    
    FUNCTION hitung_jumlah_status (STATUS_INPUT IN VARCHAR2) RETURN NUMBER IS
        jumlah NUMBER := 0;
    BEGIN
      SELECT COUNT(*) INTO jumlah
      FROM STATUS_PEMESANAN
      WHERE STATUS = STATUS_INPUT;
      RETURN jumlah;
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('tidak ada data ditemukan');
    RETURN 0;
    END hitung_jumlah_status;
    

END inur_pkg;
/
---------------------------- TRIGGER LOG  -----------------------------------
    CREATE OR REPLACE TRIGGER logoff_trig 
    BEFORE LOGOFF ON SCHEMA
    BEGIN
    INSERT INTO log_trig (user_id, log_date, action) 
    VALUES (USER, TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'), 'Logging off');
    END;
    
    CREATE OR REPLACE TRIGGER logon_trig 
    AFTER LOGON ON SCHEMA
    BEGIN
    INSERT INTO log_trig (user_id, log_date, action) 
    VALUES (USER, TO_CHAR(SYSDATE, 'DD-MON-YYYY HH24:MI:SS'), 'Logging on');
    END;
    
--------------------------- TRIGGER DELETE -------------------------------------
    CREATE OR REPLACE TRIGGER del_paket
    AFTER DELETE ON PAKETFOTO
    FOR EACH ROW
    BEGIN
    INSERT INTO info_delete (USER_ID, WAKTU, KETERANGAN) 
    VALUES  (USER, TO_CHAR (SYSDATE, 'DD-MON-YYYY HH24:MI:SS'), 
    'Terjadi penghapusan id_paket pada PAKETFOTO');
    END;

------------------------------- running ----------------------------------------
SET SERVEROUTPUT ON
SET VERIFY OFF

select * from PAKETFOTO;

execute inur_pkg.insert_foto('BABY', 'Foto Bayi', 200000);
   
execute inur_pkg.update_foto('BABY', 'Foto Bayi', 175000);

execute inur_pkg.delete_foto('BABY');

execute inur_pkg.view_foto;

DECLARE
    jumlah NUMBER;
BEGIN
    jumlah := inur_pkg.hitung_jumlah_harga(40000);
    DBMS_OUTPUT.PUT_LINE('Jumlah paket : ' || jumlah);
END;
/

SET SERVEROUTPUT ON
DECLARE
    jumlah NUMBER;
BEGIN
    jumlah := inur_pkg.hitung_jumlah_alamat_pelanggan('Jl. Bandung 17');
    DBMS_OUTPUT.PUT_LINE('Jumlah pelanggan yang tinggal : ' || jumlah);
END;
/

DECLARE
    jumlah NUMBER;
BEGIN
    jumlah := inur_pkg.hitung_jumlah_pelanggan_pesan('P-001');
    DBMS_OUTPUT.PUT_LINE('Pelanggan telah memesan sebanyak : ' || jumlah || ' pesanan' );
END;
/

DECLARE
    jumlah NUMBER;
BEGIN
    jumlah := inur_pkg.hitung_jumlah_status('DONE');
    DBMS_OUTPUT.PUT_LINE('Jumlah pesanan yang selesai : ' || jumlah || ' pesanan');
END;
/
-------------------------------------------------------------------
SELECT * FROM PELANGGAN;
SELECT * FROM PAKETFOTO;
SELECT * FROM PEMESANAN;
SELECT * FROM STATUS_PEMESANAN;
SELECT * FROM LOG_TRIG;
SELECT * FROM INFO_DELETE;


    